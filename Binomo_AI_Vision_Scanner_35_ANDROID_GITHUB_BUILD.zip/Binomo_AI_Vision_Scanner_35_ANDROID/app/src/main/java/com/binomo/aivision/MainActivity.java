package com.binomo.aivision;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView binomo;
    private WebView scanner;
    private final Handler handler = new Handler();
    private boolean serverStarted = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,14,19));

        TextView header = new TextView(this);
        header.setText("⚡ Binomo AI Vision Scanner PRO  •  Android");
        header.setTextColor(Color.WHITE); header.setTextSize(15); header.setPadding(12,8,12,8);
        root.addView(header, new LinearLayout.LayoutParams(-1, 42));

        binomo = makeWebView();
        scanner = makeWebView();
        LinearLayout.LayoutParams top = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        LinearLayout.LayoutParams bottom = new LinearLayout.LayoutParams(-1, 0, 1.35f);
        root.addView(binomo, top); root.addView(scanner, bottom);
        setContentView(root);

        startPython();
        binomo.loadUrl("https://binomo.com/");
        handler.postDelayed(() -> scanner.loadUrl("http://127.0.0.1:5001/?compact=1"), 3500);
        handler.postDelayed(captureLoop, 6000);
    }

    private WebView makeWebView() {
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.rgb(7,9,12));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(true); s.setBuiltInZoomControls(false);
        s.setUserAgentString(s.getUserAgentString()+" BinomoAIVisionAndroid/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        return w;
    }

    private void startPython() {
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        new Thread(() -> {
            try { Python.getInstance().getModule("mobile_server").callAttr("start"); serverStarted=true; }
            catch (Exception e) { runOnUiThread(() -> Toast.makeText(this,"Scanner engine failed: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show()); }
        }).start();
    }

    private final Runnable captureLoop = new Runnable() {
        @Override public void run() {
            captureBinomo();
            handler.postDelayed(this, 900);
        }
    };

    private void captureBinomo() {
        if (binomo == null || binomo.getWidth() <= 0 || binomo.getHeight() <= 0) return;
        Bitmap bmp = Bitmap.createBitmap(binomo.getWidth(), binomo.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp); binomo.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 76, out); bmp.recycle();
        byte[] data = out.toByteArray();
        new Thread(() -> postFrame(data)).start();
    }

    private void postFrame(byte[] data) {
        try {
            URL u = new URL("http://127.0.0.1:5001/api/external-frame");
            HttpURLConnection c = (HttpURLConnection)u.openConnection();
            c.setConnectTimeout(800); c.setReadTimeout(1200); c.setDoOutput(true);
            c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","image/jpeg"); c.setFixedLengthStreamingMode(data.length);
            OutputStream os=c.getOutputStream(); os.write(data); os.close(); c.getResponseCode(); c.disconnect();
        } catch(Exception ignored) {}
    }

    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); if (binomo!=null) binomo.destroy(); if (scanner!=null) scanner.destroy(); super.onDestroy(); }
    @Override public void onBackPressed() { if (binomo!=null && binomo.canGoBack()) binomo.goBack(); else super.onBackPressed(); }
}
