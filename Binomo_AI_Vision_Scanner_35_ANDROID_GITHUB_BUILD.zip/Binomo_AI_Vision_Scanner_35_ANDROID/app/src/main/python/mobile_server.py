import threading
from app.server import app, ensure_thread

def start():
    # Flask is local-only; Android WebView connects to 127.0.0.1.
    ensure_thread()
    app.run(host='127.0.0.1', port=5001, debug=False, use_reloader=False, threaded=True)
