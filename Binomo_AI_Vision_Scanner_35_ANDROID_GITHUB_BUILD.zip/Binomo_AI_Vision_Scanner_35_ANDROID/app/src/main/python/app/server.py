import os, threading, time, json, csv
from collections import deque
import numpy as np, cv2
from PIL import Image
from flask import Flask, jsonify, request, send_from_directory, Response
from dotenv import load_dotenv
from .strategies import STRATEGIES, catalog
from .vision import ScreenVision, VisionState

ROOT=os.path.dirname(os.path.dirname(__file__)); load_dotenv(os.path.join(ROOT,'.env'))
app=Flask(__name__,static_folder=os.path.join(ROOT,'static'),static_url_path='')
vision=ScreenVision(); state=VisionState(); lock=threading.Lock(); frame_lock=threading.Lock(); running=False; thread=None
external_frame=None; external_image=None; external_last=0.0; external_sequence=0; processed_sequence=0
market='Crypto IDX'; strategies_selected=['AI Auto']; timeframe='5m'; min_confidence=int(os.getenv('MIN_CONFIDENCE','80')); min_entry='B'; running_generation=0; picking=False; cloud_busy=False
trade_mode='FTT'; account_mode='PAPER_DEMO'; stake_amount=5.0; max_trades=10; target_profit=50.0; stop_loss=25.0; auto_trade=False; trades_taken=0; virtual_balance=1000.0; active_paper=[]; last_auto_key=''; lock_trade=threading.Lock()
journal=deque(maxlen=500); journal_path=os.path.join(ROOT,'.scanner_journal.json'); last_logged_key=''; last_signal_at=0.0; notify_cooldown=float(os.getenv('NOTIFY_COOLDOWN_SECONDS','60'))
reference_images={}

def load_journal():
    try:
        with open(journal_path,'r',encoding='utf-8') as f:
            data=json.load(f)
        journal.extend(data[-500:])
    except Exception:
        pass

def save_journal():
    try:
        tmp=journal_path+'.tmp'
        with open(tmp,'w',encoding='utf-8') as f: json.dump(list(journal),f,ensure_ascii=False,indent=2)
        os.replace(tmp,journal_path)
    except Exception:
        pass

def choose_expiry(s):
    if s.timeframe == '1m': return '2 min' if s.entry_quality == 'A' else '3 min'
    if s.timeframe == '5m': return '3 min' if s.entry_quality == 'A' else '5 min'
    if s.timeframe == '15m': return '5 min' if s.entry_quality == 'A' else '10 min'
    return '10 min' if s.entry_quality == 'A' else '15 min'

def auto_paper_trade(s):
    global trades_taken, virtual_balance, last_auto_key
    if not auto_trade or account_mode != 'PAPER_DEMO': return
    if s.direction not in ('UP','DOWN') or s.setup!='READY' or s.entry_quality not in ('A','B') or s.confidence < min_confidence: return
    if trades_taken >= max_trades: return
    key=f"{market}|{s.direction}|{s.selected_strategy}|{s.timeframe}|{round(time.time()/15)}"
    if key == last_auto_key: return
    with lock_trade:
        if trades_taken >= max_trades: return
        last_auto_key=key; trades_taken += 1
        amount=min(max(0.01,float(stake_amount)), max(0.0, virtual_balance))
        if amount <= 0: return
        virtual_balance=round(virtual_balance-amount,2)
        expiry=choose_expiry(s) if trade_mode=='FTT' else 'Managed by paper risk engine'
        active_paper.append({'timestamp':time.time(),'market':market,'mode':trade_mode,'direction':s.direction,'amount':amount,'expiry':expiry,'confidence':s.confidence,'strategy':s.selected_strategy,'entry_quality':s.entry_quality,'target_profit':target_profit,'stop_loss':stop_loss,'outcome':'PENDING','paper':True})

def settle_paper_trades(s):
    global virtual_balance
    now=time.time()
    with lock_trade:
        for t in active_paper:
            if t['outcome']!='PENDING': continue
            age=now-t['timestamp']
            needed=120 if t['mode']=='FTT' else 60
            if age < needed: continue
            if s.direction == t['direction']:
                if t['mode']=='FTT':
                    profit=round(t['amount']*0.8,2); virtual_balance=round(virtual_balance+t['amount']+profit,2); t['outcome']='WIN'; t['pnl']=profit
                else:
                    profit=round(min(target_profit, t['amount']*1.5),2); virtual_balance=round(virtual_balance+t['amount']+profit,2); t['outcome']='WIN'; t['pnl']=profit
            elif s.direction in ('UP','DOWN') and s.direction != t['direction']:
                loss=round(t['amount'] if t['mode']=='FTT' else min(stop_loss,t['amount']),2); t['outcome']='LOSS'; t['pnl']=-loss
            else:
                continue

def _log_signal(s):
    global last_logged_key,last_signal_at
    if s.direction not in ('UP','DOWN') or s.setup!='READY': return
    key=f"{market}|{s.direction}|{s.selected_strategy}|{s.timeframe}"
    now=time.time()
    if key==last_logged_key and now-last_signal_at<notify_cooldown: return
    last_logged_key=key; last_signal_at=now
    journal.appendleft({'timestamp':now,'market':market,'strategy':s.selected_strategy,'direction':s.direction,'confidence':s.confidence,'entry_quality':s.entry_quality,'regime':s.regime,'timeframe':s.timeframe,'expiry':s.expiry,'outcome':'PENDING','reason':s.reason}); save_journal()

def loop():
    global state,last_capture,external_frame,external_image,external_last,external_sequence,processed_sequence,cloud_busy
    last_capture=0
    while running:
        try:
            with frame_lock:
                image=external_image.copy() if external_image is not None else None; bgr=external_frame.copy() if external_frame is not None else None; seq=external_sequence; age=time.time()-external_last if external_last else 999
            if image is None or bgr is None:
                time.sleep(.04); continue
            elif seq!=processed_sequence:
                vision.capture_mode='embedded-binomo'; processed_sequence=seq
            else:
                # Never spin on the same frame. This is the key to responsiveness.
                time.sleep(.04); continue
            f=vision.features(bgr); refs=vision.reference_features(); s=vision.local_reason(f,strategies_selected,market,timeframe,min_confidence,min_entry,refs); s.age_seconds=round(age,2); s.stale=age>2.5
            if s.stale: s.direction='WAIT'; s.confidence=min(s.confidence,50); s.setup='WAITING'; s.reason='WAIT: the browser feed is stale. Waiting for a fresh chart frame.'
            auto_paper_trade(s); settle_paper_trades(s)
            with lock: state=s; last_capture=time.time()
            _log_signal(s)
            if not s.stale and s.direction in ('UP','DOWN') and not cloud_busy and os.getenv('OPENAI_API_KEY','').strip():
                cloud_busy=True
                def worker(img,base):
                    global cloud_busy,state
                    try:
                        reviewed=vision.cloud_reason(img,base,strategies_selected,market,timeframe)
                        with lock: state=reviewed
                    finally: cloud_busy=False
                threading.Thread(target=worker,args=(image.copy(),s),daemon=True).start()
        except Exception as e:
            with lock: state=VisionState(False,0,0,0,'UNCLEAR','NEUTRAL','NONE','WAITING','WAIT',0,'Scanner engine error: '+type(e).__name__,'5m','2+ minutes','ERROR','LOCAL',0,'UNKNOWN','C',0,0,0,0,0,0,'AI Auto',{},'Restart the scanner if the error persists.',True,999,'SINGLE')
        time.sleep(float(os.getenv('CAPTURE_INTERVAL_SECONDS','0.12')))

def ensure_thread():
    global running,thread
    if not running or thread is None or not thread.is_alive():
        running=True; thread=threading.Thread(target=loop,daemon=True); thread.start()

def catalog_with_auto(): return [{'name':'AI Auto','professional':True,'guidance':'Automatically select the strongest strategy for the detected market regime and visible setup.'}]+catalog()

@app.get('/')
def index(): return send_from_directory(app.static_folder,'index.html')
@app.get('/api/health')
def health(): return jsonify({'ok':True,'running':running,'external_browser_connected':bool(external_last and time.time()-external_last<2.5)})
@app.get('/api/status')
def status():
    with lock: s=VisionState(**state.__dict__)
    age=round(time.time()-external_last,2) if external_last else None
    if external_last and age>2.5 and vision.capture_mode=='embedded-binomo':
        s.direction='WAIT'; s.confidence=min(s.confidence,50); s.setup='WAITING'; s.stale=True; s.age_seconds=age
        s.reason='WAIT: the embedded browser feed is stale. Waiting for a fresh chart frame.'
    return jsonify({'running':running,'picking':picking,'market':market,'strategies':strategies_selected,'strategy':s.selected_strategy,'last_capture':last_capture,'browser_last_frame':external_last,'frame_age':age,'state':{**s.__dict__,'capture_mode':vision.capture_mode,'source_hwnd':vision.source_hwnd},'settings':{'timeframe':timeframe,'min_confidence':min_confidence,'min_entry':min_entry,'trade_mode':trade_mode,'account_mode':account_mode,'stake_amount':stake_amount,'max_trades':max_trades,'target_profit':target_profit,'stop_loss':stop_loss,'auto_trade':auto_trade,'trades_taken':trades_taken,'virtual_balance':virtual_balance,'paper_trades':active_paper[-20:]}})
@app.get('/api/strategies')
def strategies(): return jsonify(catalog_with_auto())
@app.post('/api/config')
def config():
    global market,strategies_selected,timeframe,min_confidence,min_entry
    body=request.get_json(force=True) or {}; market=str(body.get('market',market)).strip() or market
    selected=body.get('strategies',strategies_selected); selected=[selected] if isinstance(selected,str) else [str(x).strip() for x in selected if str(x).strip()]
    if not selected: return jsonify({'error':'Select at least one strategy'}),400
    if 'AI Auto' in selected: selected=['AI Auto']
    unknown=[x for x in selected if x not in STRATEGIES and x!='AI Auto']
    if unknown: return jsonify({'error':'Unknown strategy: '+unknown[0]}),400
    tf=str(body.get('timeframe',timeframe));
    if tf not in ('1m','5m','15m','30m'): return jsonify({'error':'Timeframe must be 1m, 5m, 15m or 30m'}),400
    try: mc=max(50,min(99,int(body.get('min_confidence',min_confidence))))
    except: mc=min_confidence
    me=str(body.get('min_entry',min_entry)).upper(); me=me if me in ('A','B','C') else 'B'
    market=market; strategies_selected=list(dict.fromkeys(selected)); timeframe=tf; min_confidence=mc; min_entry=me; vision.reset_history(); ensure_thread()
    return jsonify({'ok':True,'market':market,'strategies':strategies_selected,'timeframe':timeframe,'min_confidence':min_confidence,'min_entry':min_entry})
@app.post('/api/trading-config')
def trading_config():
    global trade_mode, account_mode, stake_amount, max_trades, target_profit, stop_loss, auto_trade, trades_taken
    body=request.get_json(force=True) or {}
    mode=str(body.get('trade_mode',trade_mode)).upper()
    acct=str(body.get('account_mode',account_mode)).upper()
    if mode not in ('FTT','CFD'): return jsonify({'error':'Trading mode must be FTT or CFD'}),400
    if acct not in ('PAPER_DEMO','MANUAL_REAL'): return jsonify({'error':'Account mode must be PAPER_DEMO or MANUAL_REAL'}),400
    try: amt=max(0.01,float(body.get('stake_amount',stake_amount)))
    except: return jsonify({'error':'Trading amount must be a number'}),400
    try: n=max(1,min(100,int(body.get('max_trades',max_trades))))
    except: return jsonify({'error':'Number of trades must be an integer'}),400
    try: tp=max(0.01,float(body.get('target_profit',target_profit))); sl=max(0.01,float(body.get('stop_loss',stop_loss)))
    except: return jsonify({'error':'Target profit and stop loss must be numbers'}),400
    trade_mode=mode; account_mode=acct; stake_amount=amt; max_trades=n; target_profit=tp; stop_loss=sl; auto_trade=bool(body.get('auto_trade',auto_trade)); trades_taken=0
    return jsonify({'ok':True,'trade_mode':trade_mode,'account_mode':account_mode,'stake_amount':stake_amount,'max_trades':max_trades,'target_profit':target_profit,'stop_loss':stop_loss,'auto_trade':auto_trade,'warning':'Automatic trading is PAPER_DEMO only. REAL mode produces copy signals for manual confirmation.' if acct=='MANUAL_REAL' else 'Paper demo only; this does not place trades on Binomo.'})

@app.post('/api/reset-paper')
def reset_paper():
    global virtual_balance, trades_taken, active_paper, last_auto_key
    try: balance=max(0.0,float((request.get_json(force=True) or {}).get('balance',1000)))
    except: balance=1000.0
    virtual_balance=round(balance,2); trades_taken=0; active_paper=[]; last_auto_key=''; return jsonify({'ok':True,'virtual_balance':virtual_balance})

@app.get('/api/copy-signal')
def copy_signal():
    with lock: s=VisionState(**state.__dict__)
    if s.direction not in ('UP','DOWN') or s.setup!='READY' or s.confidence<min_confidence or s.entry_quality not in ('A','B'):
        return jsonify({'ready':False,'reason':s.reason,'market':market})
    return jsonify({'ready':True,'market':market,'mode':trade_mode,'direction':s.direction,'confidence':s.confidence,'entry_quality':s.entry_quality,'strategy':s.selected_strategy,'timeframe':s.timeframe,'expiry':choose_expiry(s),'amount':stake_amount,'target_profit':target_profit,'stop_loss':stop_loss,'reason':s.reason,'timestamp':time.time()})

@app.post('/api/region')
def region():
    body=request.get_json(force=True) or {}
    try:
        vals={k:max(1,int(body[k])) for k in ('left','top','width','height')}; vision.set_region(vals); vision.reset_history(); ensure_thread(); return jsonify({'ok':True,'region':vals,'capture_mode':vision.capture_mode})
    except Exception: return jsonify({'error':'Region values must be integers'}),400
@app.post('/api/pick-region')
def pick():
    global picking
    if picking: return jsonify({'ok':False,'busy':True,'message':'Chart selection is already running.'}),409
    def worker():
        global picking
        try:
            vals=pick_region(delay_seconds=3)
            if vals: vision.set_region(vals); vision.reset_history(); ensure_thread()
        finally: picking=False
    picking=True; threading.Thread(target=worker,daemon=True).start(); return jsonify({'ok':True,'started':True,'message':'Switch to your chart now. Selection opens in 3 seconds.'})
@app.post('/api/start')
def start(): ensure_thread(); return jsonify({'ok':True})
@app.post('/api/stop')
def stop():
    global running; running=False; return jsonify({'ok':True})
@app.post('/api/external-frame')
def external_frame_endpoint():
    global external_frame,external_image,external_last,external_sequence
    try:
        raw=request.get_data(); arr=np.frombuffer(raw,dtype=np.uint8); bgr=cv2.imdecode(arr,cv2.IMREAD_COLOR)
        if bgr is None: return jsonify({'error':'invalid image'}),400
        rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
        with frame_lock: external_frame=bgr; external_image=Image.fromarray(rgb); external_last=time.time(); external_sequence+=1; seq=external_sequence
        return jsonify({'ok':True,'timestamp':external_last,'sequence':seq})
    except Exception as e: return jsonify({'error':type(e).__name__}),400
@app.get('/api/screenshot')
def screenshot():
    with frame_lock: image=external_image.copy() if external_image is not None else None
    if image is None: image,_=vision.capture()
    b=__import__('io').BytesIO(); image.save(b,'JPEG',quality=72); return Response(b.getvalue(),mimetype='image/jpeg',headers={'Cache-Control':'no-store'})
@app.get('/api/external-status')
def external_status(): return jsonify({'connected':bool(external_last and time.time()-external_last<2.5),'last_frame':external_last,'age':round(time.time()-external_last,2) if external_last else None})
@app.post('/api/reference-frame/<tf>')
def reference_frame(tf):
    if tf not in ('1m','5m','15m','30m'): return jsonify({'error':'Invalid reference timeframe'}),400
    raw=request.get_data(); arr=np.frombuffer(raw,dtype=np.uint8); bgr=cv2.imdecode(arr,cv2.IMREAD_COLOR)
    if bgr is None: return jsonify({'error':'invalid image'}),400
    vision.set_reference(tf,bgr); return jsonify({'ok':True,'timeframe':tf,'timestamp':time.time()})
@app.get('/api/references')
def references():
    now=time.time(); return jsonify({tf:{'age':round(now-ts,1)} for tf,(ts,_) in vision.reference_frames.items()})
@app.get('/api/metrics')
def metrics():
    pending=sum(x['outcome']=='PENDING' for x in journal); wins=sum(x['outcome']=='WIN' for x in journal); losses=sum(x['outcome']=='LOSS' for x in journal); resolved=wins+losses
    by_strategy={}
    for x in journal:
        if x['outcome'] not in ('WIN','LOSS'): continue
        g=by_strategy.setdefault(x['strategy'],{'wins':0,'losses':0})
        g['wins'] += x['outcome']=='WIN'; g['losses'] += x['outcome']=='LOSS'
    for g in by_strategy.values():
        r=g['wins']+g['losses']; g['resolved']=r; g['win_rate']=round(100*g['wins']/r,1) if r else None
    return jsonify({'signals_total':len(journal),'pending':pending,'wins':wins,'losses':losses,'resolved':resolved,'win_rate':round(100*wins/resolved,1) if resolved else None,'by_strategy':by_strategy})
@app.get('/api/journal')
def get_journal(): return jsonify(list(journal))
@app.post('/api/journal/outcome')
def outcome():
    body=request.get_json(force=True) or {}; idx=int(body.get('index',-1)); value=str(body.get('outcome','')).upper()
    if idx<0 or idx>=len(journal) or value not in ('WIN','LOSS','SKIP'): return jsonify({'error':'Invalid journal update'}),400
    journal[idx]['outcome']=value; save_journal(); return jsonify({'ok':True,'entry':journal[idx]})

load_journal()
ensure_thread()
