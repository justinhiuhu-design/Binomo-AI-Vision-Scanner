STRATEGIES = [
'Quantum Surge','2EMA + RSI','5ST RSI + Bollinger Bands','Alligator + Awesome Oscillator',
"Bollinger’s Friend (BB, MACD)",'Bollinger Breakdown','Crypto (SMA, EMA, HMA, MACD)',
'Double Punch (FTT + 5ST)',"Elder’s Triple Screen",'Engulfing','Fast and Furious (5ST + Multi-Window)',
'Fibonacci Levels','Ichimoku','Trading on the News','Night Channel / After-hours',
'Price Correction (RSI divergence)','Heikin Ashi','Fast Ride (EMA, MACD)','Fractals',
'Pathfinder (BB, RSI, SMA)','Extra Ordinary Strategy (EMA)','Dynamic Momentum Swing (RSI + MACD)',
'Demand & Supply Zones','Support & Resistance Reversal','Market Structure (HH/HL + LH/LL)',
'Breakout & Retest','Liquidity Sweep Reversal','Order Block Rejection','Fair Value Gap Continuation',
'VWAP Trend Confirmation','RSI Divergence Reversal','EMA Pullback + RSI','Stochastic Momentum Reversal',
'Pin Bar + Engulfing Confirmation','Trend-Following + Momentum Trading'
]

GUIDANCE = {
'Demand & Supply Zones':'Find fresh demand/supply zones; wait for price to return and show rejection/confirmation.',
'Support & Resistance Reversal':'Look for a clean reaction at a well-tested support/resistance area with confirmation.',
'Market Structure (HH/HL + LH/LL)':'Determine HH/HL bullish or LH/LL bearish structure; avoid unclear/choppy structure.',
'Breakout & Retest':'Require a genuine level break followed by a retest and directional confirmation.',
'Liquidity Sweep Reversal':'Look for a sweep beyond an obvious high/low followed by rejection back inside the range.',
'Order Block Rejection':'Identify a meaningful order-block area and require rejection plus directional confirmation.',
'Fair Value Gap Continuation':'Look for a visible imbalance/FVG and confirmation that price is continuing in the original direction.',
'VWAP Trend Confirmation':'Use visible VWAP relationship and slope to confirm directional bias; avoid flat/choppy VWAP.',
'RSI Divergence Reversal':'Use visible momentum divergence only with price-action confirmation; do not trade divergence alone.',
'EMA Pullback + RSI':'Require directional EMA alignment, pullback into the EMA area, and RSI confirmation.',
'Stochastic Momentum Reversal':'Require stochastic reversal from an extreme plus price-action confirmation.',
'Pin Bar + Engulfing Confirmation':'Require a clear rejection pin bar or engulfing candle at a meaningful area.',
'Trend-Following + Momentum Trading':'Trade with the dominant directional move only when trend structure and momentum agree; prefer pullback/retest entries, strong candle confirmation, and avoid sideways/choppy markets.'
}

def catalog():
    return [{'name': s, 'professional': s in GUIDANCE, 'guidance': GUIDANCE.get(s,'Use the selected strategy rules visible from the chart; require confirmation before entry.')} for s in STRATEGIES]
