import base64, io, os, time, json, math, sys, ctypes, ctypes.wintypes
from dataclasses import dataclass, asdict
from collections import deque
import numpy as np
import cv2
from PIL import Image
import requests
from .strategies import GUIDANCE, STRATEGIES

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_=[('biSize',ctypes.wintypes.DWORD),('biWidth',ctypes.wintypes.LONG),('biHeight',ctypes.wintypes.LONG),('biPlanes',ctypes.wintypes.WORD),('biBitCount',ctypes.wintypes.WORD),('biCompression',ctypes.wintypes.DWORD),('biSizeImage',ctypes.wintypes.DWORD),('biXPelsPerMeter',ctypes.wintypes.LONG),('biYPelsPerMeter',ctypes.wintypes.LONG),('biClrUsed',ctypes.wintypes.DWORD),('biClrImportant',ctypes.wintypes.DWORD)]
class BITMAPINFO(ctypes.Structure):
    _fields_=[('bmiHeader',BITMAPINFOHEADER),('bmiColors',ctypes.c_uint32*1)]

@dataclass
class VisionState:
    captured: bool=False; candles:int=0; bullish_ratio:float=0.0; bearish_ratio:float=0.0
    trend:str='UNCLEAR'; momentum:str='NEUTRAL'; rejection:str='NONE'; setup:str='WAITING'
    direction:str='WAIT'; confidence:int=0; reason:str='Waiting for enough visual evidence.'
    timeframe:str='5m'; expiry:str='2+ minutes'; chart_quality:str='UNKNOWN'; last_ai:str='LOCAL'
    screen_change:float=0.0; regime:str='UNKNOWN'; entry_quality:str='C'; evidence_score:int=0
    trend_score:int=0; momentum_score:int=0; structure_score:int=0; level_score:int=0
    confirmation_score:int=0; selected_strategy:str='AI Auto'; strategy_scores:dict=None
    invalidation:str='Wait for a clear structure break or loss of confirmation.'
    stale:bool=False; age_seconds:float=0.0; multi_timeframe:str='SINGLE'

    def __post_init__(self):
        if self.strategy_scores is None: self.strategy_scores={}

class ScreenVision:
    def __init__(self):
        self.region={'left':100,'top':100,'width':900,'height':600}; self.history=deque(maxlen=18)
        self.feature_history=deque(maxlen=18); self.last_cloud=0; self.last_frame_small=None; self.last_change=0.0
        self.source_hwnd=0; self.source_window_left=0; self.source_window_top=0; self.source_offset_x=0; self.source_offset_y=0
        self.capture_mode='screen'; self.last_external_at=0.0; self.reference_frames={}

    def set_region(self, vals):
        self.region={k:int(vals[k]) for k in ('left','top','width','height')}; self.source_hwnd=int(vals.get('source_hwnd',0) or 0)
        self.source_window_left=int(vals.get('source_window_left',0) or 0); self.source_window_top=int(vals.get('source_window_top',0) or 0)
        self.source_offset_x=int(vals.get('source_offset_x',self.region['left']-self.source_window_left) or 0); self.source_offset_y=int(vals.get('source_offset_y',self.region['top']-self.source_window_top) or 0)
        self.capture_mode='window' if self.source_hwnd else 'screen'

    def reset_history(self):
        self.history.clear(); self.feature_history.clear(); self.last_frame_small=None; self.last_change=0.0

    def _capture_window(self):
        if sys.platform!='win32' or not self.source_hwnd: return None
        user32=ctypes.windll.user32; gdi32=ctypes.windll.gdi32; hwnd=ctypes.wintypes.HWND(self.source_hwnd); rect=ctypes.wintypes.RECT()
        if not user32.GetWindowRect(hwnd,ctypes.byref(rect)): return None
        ww=max(1,rect.right-rect.left); wh=max(1,rect.bottom-rect.top); hdc=user32.GetWindowDC(hwnd)
        if not hdc: return None
        mem=gdi32.CreateCompatibleDC(hdc); hb=gdi32.CreateCompatibleBitmap(hdc,ww,wh)
        if not mem or not hb:
            if mem: gdi32.DeleteDC(mem)
            user32.ReleaseDC(hwnd,hdc); return None
        old=gdi32.SelectObject(mem,hb); ok=user32.PrintWindow(hwnd,mem,2)
        bmi=BITMAPINFO(); bmi.bmiHeader.biSize=ctypes.sizeof(BITMAPINFOHEADER); bmi.bmiHeader.biWidth=ww; bmi.bmiHeader.biHeight=-wh; bmi.bmiHeader.biPlanes=1; bmi.bmiHeader.biBitCount=32; bmi.bmiHeader.biCompression=0
        buf=ctypes.create_string_buffer(ww*wh*4); got=gdi32.GetDIBits(mem,hb,0,wh,buf,ctypes.byref(bmi),0)
        gdi32.SelectObject(mem,old); gdi32.DeleteObject(hb); gdi32.DeleteDC(mem); user32.ReleaseDC(hwnd,hdc)
        if not ok or not got: return None
        raw=np.frombuffer(buf,dtype=np.uint8).reshape((wh,ww,4)); x=int(self.source_offset_x); y=int(self.source_offset_y); w=int(self.region['width']); h=int(self.region['height'])
        if x<0 or y<0 or x+w>ww or y+h>wh: return None
        return raw[y:y+h,x:x+w].copy()

    def capture(self):
        raise RuntimeError("Android mode requires an external WebView frame")

    def _mask_colors(bgr):
        hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV)
        bull=cv2.inRange(hsv,np.array([35,45,45]),np.array([105,255,255]))
        bear=cv2.bitwise_or(cv2.inRange(hsv,np.array([0,45,45]),np.array([15,255,255])),cv2.inRange(hsv,np.array([160,40,45]),np.array([179,255,255])))
        kernel=np.ones((3,3),np.uint8)
        return cv2.morphologyEx(bull,cv2.MORPH_CLOSE,kernel),cv2.morphologyEx(bear,cv2.MORPH_CLOSE,kernel)

    def _extract_candles(self,bgr,bull_mask,bear_mask):
        h,w=bgr.shape[:2]; union=cv2.bitwise_or(bull_mask,bear_mask); contours,_=cv2.findContours(union,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        candidates=[]
        for c in contours:
            x,y,cw,ch=cv2.boundingRect(c); area=cv2.contourArea(c)
            if area<10 or cw<2 or cw>max(10,int(w*.06)) or ch<5 or ch>int(h*.75): continue
            candidates.append((x,y,cw,ch,area))
        candidates.sort(key=lambda z:z[0]); groups=[]
        for item in candidates:
            x,y,cw,ch,area=item; center=x+cw/2; placed=False
            for g in groups[-15:]:
                gx,gy,gw,gh,ga,gi=g; gc=gx+gw/2
                if abs(center-gc)<=max(7,cw*1.8):
                    nx=min(gx,x); ny=min(gy,y); nr=max(gx+gw,x+cw); nb=max(gy+gh,y+ch); g[:5]=[nx,ny,nr-nx,nb-ny,ga+area]; gi.append(item); placed=True; break
            if not placed: groups.append([x,y,cw,ch,area,[item]])
        groups=[g for g in groups if 3<=g[2]<=max(35,int(w*.075)) and g[3]>=5][-45:]
        out=[]
        for g in groups:
            x,y,cw,ch,area,_=g; sl=(slice(max(0,y),min(h,y+ch)),slice(max(0,x),min(w,x+cw)))
            bp=float(np.mean(bull_mask[sl]>0)); rp=float(np.mean(bear_mask[sl]>0)); total=bp+rp
            if total<.07: continue
            side='UP' if bp/total>=.58 else 'DOWN' if bp/total<=.42 else 'MIXED'
            out.append({'x':x,'y':y,'w':cw,'h':ch,'bp':bp,'rp':rp,'side':side,'strength':abs(bp-rp)/(total+1e-6)})
        return out

    def features(self,bgr):
        h,w=bgr.shape[:2]; gray=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY); small=cv2.resize(gray,(160,90))
        change=100.0 if self.last_frame_small is None else float(np.mean(cv2.absdiff(small,self.last_frame_small))); self.last_frame_small=small; self.last_change=change
        edges=cv2.Canny(gray,50,150); edge_density=float(np.mean(edges>0)); bull_mask,bear_mask=self._mask_colors(bgr); candles=self._extract_candles(bgr,bull_mask,bear_mask)
        if not candles: return {'width':w,'height':h,'edge_density':edge_density,'candles':0,'bullish':0,'bearish':0,'bullish_ratio':.5,'bearish_ratio':.5,'recent_bullish_ratio':.5,'trend':'UNCLEAR','momentum':'NEUTRAL','rejection':'NONE','chart_quality':'LOW','screen_change':round(change,2),'structure':'UNCLEAR','support_y':None,'resistance_y':None,'slope':0,'volatility':'UNKNOWN','candle_data':[]}
        bullish=sum(c['side']=='UP' for c in candles); bearish=sum(c['side']=='DOWN' for c in candles); total=max(1,bullish+bearish); br=bullish/total; rr=bearish/total
        recent=candles[-12:]; rb=sum(c['side']=='UP' for c in recent); rd=sum(c['side']=='DOWN' for c in recent); rn=max(1,rb+rd); recent_ratio=rb/rn
        if recent_ratio>=.67: momentum='BULLISH'
        elif recent_ratio<=.33: momentum='BEARISH'
        else: momentum='MIXED'
        if br>=.62 and recent_ratio>=.58: trend='BULLISH'
        elif rr>=.62 and recent_ratio<=.42: trend='BEARISH'
        elif len(candles)>=6: trend='MIXED'
        else: trend='UNCLEAR'
        # Estimate price path from candle vertical centers; screen y is inverted price.
        centers=np.array([c['y']+c['h']/2 for c in candles[-20:]],dtype=float); xs=np.arange(len(centers),dtype=float)
        slope=float(np.polyfit(xs,centers,1)[0]) if len(centers)>=4 else 0.0
        dif=np.diff(centers); noise=float(np.std(dif)) if len(dif) else 0.0
        structure='HIGHER_HIGHS_LOWS' if slope < -1.2 and trend=='BULLISH' else 'LOWER_HIGHS_LOWS' if slope > 1.2 and trend=='BEARISH' else 'RANGE' if abs(slope)<.9 else 'MIXED'
        # Level density from candle top/bottom clusters.
        levels=np.array([c['y'] for c in candles]+[c['y']+c['h'] for c in candles],dtype=float)
        support=resistance=None
        if len(levels)>=8:
            hist=np.histogram(levels,bins=max(8,min(24,h//30)))[0]; inds=np.argsort(hist)[-4:]; centers_y=np.histogram_bin_edges(levels,bins=max(8,min(24,h//30))); picks=[(centers_y[i]+centers_y[i+1])/2 for i in inds]
            support=float(max(picks)); resistance=float(min(picks))
        rejection='NONE'
        last=candles[-1]
        if last['h']>max(10,h*.05) and last['strength']<.34: rejection='POSSIBLE'
        quality='GOOD' if len(candles)>=8 and edge_density>=.004 else 'FAIR' if len(candles)>=5 and edge_density>=.002 else 'LOW'
        vol='HIGH' if noise>7 else 'MEDIUM' if noise>3 else 'LOW'
        return {'width':w,'height':h,'edge_density':edge_density,'candles':len(candles),'bullish':bullish,'bearish':bearish,'bullish_ratio':br,'bearish_ratio':rr,'recent_bullish_ratio':recent_ratio,'trend':trend,'momentum':momentum,'rejection':rejection,'chart_quality':quality,'screen_change':round(change,2),'structure':structure,'support_y':support,'resistance_y':resistance,'slope':slope,'volatility':vol,'candle_data':candles}

    def set_reference(self, timeframe, bgr):
        self.reference_frames[str(timeframe)] = (time.time(), bgr.copy())

    def reference_features(self, max_age=300):
        out={}
        now=time.time()
        for tf,(ts,bgr) in list(self.reference_frames.items()):
            if now-ts <= max_age:
                out[tf] = self.features(bgr)
        return out

    def _regime(self,f):
        if f['chart_quality']=='LOW': return 'UNKNOWN'
        if f['volatility']=='HIGH' and f['trend'] in ('BULLISH','BEARISH'): return 'TRENDING-VOLATILE'
        if f['trend'] in ('BULLISH','BEARISH') and f['momentum'] in ('BULLISH','BEARISH'): return 'TRENDING'
        if f['structure']=='RANGE' and f['volatility']!='HIGH': return 'RANGING'
        return 'CHOPPY'

    def _strategy_score(self,name,f,regime):
        score=35; reasons=[]
        if name=='AI Auto': return 0
        if f['chart_quality']=='GOOD': score+=12
        if f['trend'] in ('BULLISH','BEARISH'): score+=12; reasons.append('directional trend')
        if f['momentum'] in ('BULLISH','BEARISH'): score+=10; reasons.append('momentum')
        if f['trend']==f['momentum']: score+=12; reasons.append('trend/momentum aligned')
        if f['rejection']=='POSSIBLE': score+=5
        if name in GUIDANCE: score+=4
        text=GUIDANCE.get(name,'').lower()
        if 'range' in text and regime=='RANGING': score+=8
        if any(k in text for k in ('breakout','continuation','trend','ema','vwap','momentum')) and regime=='TRENDING': score+=7
        if any(k in text for k in ('reversal','rejection','divergence','support','supply')) and f['rejection']=='POSSIBLE': score+=7
        if regime=='CHOPPY': score-=15
        return max(0,min(100,score))

    def local_reason(self,f,strategies,market,timeframe='5m',min_confidence=80,min_entry='B',references=None):
        if isinstance(strategies,str): strategies=[strategies]
        regime=self._regime(f); scores={s:self._strategy_score(s,f,regime) for s in strategies if s!='AI Auto'}
        if 'AI Auto' in strategies:
            all_scores={s:self._strategy_score(s,f,regime) for s in STRATEGIES if s!='AI Auto'}; best=max(all_scores,key=all_scores.get) if all_scores else 'Trend-Following + Momentum Trading'; scores={best:all_scores[best]}; selected=best
        else: selected=max(scores,key=scores.get) if scores else 'AI Auto'
        guide=GUIDANCE.get(selected,'Evaluate the clearest visible setup and do not force a trade.')
        consensus_count=sum(1 for v in scores.values() if v>=65) if scores else 0
        consensus_required=max(1, math.ceil(len(scores)*0.5)) if scores else 1
        references=references or {}; mtf='SINGLE'; mtf_ok=True
        if references:
            mtf='ALIGNED'
            for tf,rf in references.items():
                if tf == timeframe: continue
                if rf.get('trend') in ('BULLISH','BEARISH') and f.get('trend') in ('BULLISH','BEARISH') and rf.get('trend') != f.get('trend'):
                    mtf_ok=False; mtf='CONFLICT'
            aligned=sum(1 for rf in references.values() if rf.get('trend')==f.get('trend') and f.get('trend') in ('BULLISH','BEARISH'))
            if aligned>=2: mtf='ALIGNED'
            elif not mtf_ok: mtf='CONFLICT'
            else: mtf='PARTIAL'
        trend_score=100 if f['trend'] in ('BULLISH','BEARISH') else 35; momentum_score=100 if f['momentum'] in ('BULLISH','BEARISH') else 35
        structure_score=100 if f['structure'] in ('HIGHER_HIGHS_LOWS','LOWER_HIGHS_LOWS') else 55 if f['structure']=='RANGE' else 35
        level_score=70 if f['support_y'] is not None or f['resistance_y'] is not None else 30
        alignment=100 if f['trend']==f['momentum'] and f['trend'] in ('BULLISH','BEARISH') else 20
        evidence=int(.24*trend_score+.22*momentum_score+.18*structure_score+.12*level_score+.24*alignment)
        bias='UP' if f['trend']=='BULLISH' and f['momentum']=='BULLISH' else 'DOWN' if f['trend']=='BEARISH' and f['momentum']=='BEARISH' else 'WAIT'
        self.history.append(bias); self.feature_history.append(f)
        last=list(self.history); persistent=bias in ('UP','DOWN') and len(last)>=3 and last[-1]==last[-2]==last[-3]
        change_ok=f['screen_change']>=.35
        confirmations=sum([f['trend']==('BULLISH' if bias=='UP' else 'BEARISH'),f['momentum']==('BULLISH' if bias=='UP' else 'BEARISH'),f['structure'] in ('HIGHER_HIGHS_LOWS','LOWER_HIGHS_LOWS'),f['rejection']=='POSSIBLE',regime.startswith('TRENDING')]) if bias!='WAIT' else 0
        conf=min(97,int(evidence*.55+scores.get(selected,0)*.25+confirmations*4+min(8,max(0,f['candles']-8))))
        if regime=='CHOPPY': conf=min(conf,68)
        if not mtf_ok: conf=min(conf,62)
        if not change_ok: conf=min(conf,65)
        entry='A' if evidence>=82 and persistent and confirmations>=4 and f['chart_quality']=='GOOD' else 'B' if evidence>=68 and (persistent or confirmations>=3) else 'C'
        blocked=[]
        if f['chart_quality']=='LOW': blocked.append('chart quality is low')
        if regime=='CHOPPY': blocked.append('market is choppy')
        if bias=='WAIT': blocked.append('trend and momentum are not aligned')
        if not persistent: blocked.append('direction has not persisted for 3 observations')
        if not change_ok: blocked.append('new visual movement is too small')
        if f['volatility']=='HIGH' and regime!='TRENDING-VOLATILE': blocked.append('volatility is unstable')
        if len(strategies)>1 and consensus_count<consensus_required: blocked.append('selected strategies do not have enough consensus')
        if not mtf_ok: blocked.append('higher-timeframe reference conflicts with the primary chart')
        ready=(bias in ('UP','DOWN') and entry<=min_entry and conf>=min_confidence and not blocked)
        if ready:
            setup='READY'; direction=bias; reason=f"{selected}: trend, momentum and price structure align. Evidence {evidence}/100; entry quality {entry}. Wait for the next clean confirmation candle; invalidate if structure breaks."
        elif bias in ('UP','DOWN'):
            setup='CONFIRMING' if persistent else 'FORMING'; direction='WAIT'; reason=f"Potential {bias} setup detected, but the confirmation gate is not complete: {'; '.join(blocked[:3]) or 'entry quality/confidence below threshold'}. Strategy focus: {guide}"
        else:
            setup='WAITING'; direction='WAIT'; reason=f"NO-TRADE: {'; '.join(blocked[:3]) or 'no clean directional setup'}. Strategy focus: {guide}"
        expiry='2+ minutes' if timeframe in ('1m','5m') else '5+ minutes'
        return VisionState(True,f['candles'],f['bullish_ratio'],f['bearish_ratio'],f['trend'],f['momentum'],f['rejection'],setup,direction,conf,reason,timeframe,expiry,f['chart_quality'],'LOCAL',f['screen_change'],regime,entry,evidence,trend_score,momentum_score,structure_score,level_score,int(alignment),selected,scores,'Invalidate on a clear structure break or loss of trend/momentum alignment.',False,0.0,mtf)

    def cloud_reason(self,image,state,strategies,market,timeframe='5m'):
        key=os.getenv('OPENAI_API_KEY','').strip()
        if not key or time.time()-self.last_cloud<5: return state
        self.last_cloud=time.time(); buf=io.BytesIO(); image.save(buf,format='JPEG',quality=84); b64=base64.b64encode(buf.getvalue()).decode()
        if isinstance(strategies,str): strategies=[strategies]
        guide=' | '.join(GUIDANCE.get(x,'Use visible price action and require confirmation.') for x in strategies if x!='AI Auto') or 'Choose the strongest visible setup.'
        prompt=(f"You are a conservative chart-vision reviewer for fixed-time trading analysis. Market={market}; visible chart timeframe={timeframe}; selected strategies={strategies}. Rules={guide}. "
        "Analyze ONLY the chart/price area. Ignore browser chrome, account balances, buttons and decorative UI. Do not invent indicator values that are not visibly present. Evaluate trend, momentum, higher/lower highs and lows, pullback/retest, support/resistance, supply/demand, rejection, breakout quality, divergence and choppiness when visible. "
        "The local engine has already proposed a state; your job is to confirm or veto it, not manufacture a trade. WAIT whenever evidence is obscured, contradictory, stale, choppy, or lacks a clean entry. Return JSON with direction, confidence, setup, reason, timeframe, expiry, evidence_quality, entry_quality, regime, invalidation.")
        try:
            payload={'model':os.getenv('OPENAI_VISION_MODEL','gpt-4.1-mini'),'input':[{'role':'user','content':[{'type':'input_text','text':prompt},{'type':'input_image','image_url':'data:image/jpeg;base64,'+b64}]}]}
            r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json=payload,timeout=20); r.raise_for_status(); data=r.json(); text=data.get('output_text','').strip()
            if not text:
                for item in data.get('output',[]):
                    for c in item.get('content',[]):
                        if c.get('type') in ('output_text','text'): text+=c.get('text','')
            obj=json.loads(text.strip()); d=str(obj.get('direction','WAIT')).upper(); c=max(0,min(100,int(obj.get('confidence',0))))
            if d not in ('UP','DOWN','WAIT'): d='WAIT'
            e=str(obj.get('entry_quality',state.entry_quality)).upper(); e=e if e in ('A','B','C') else state.entry_quality
            ai_reg=str(obj.get('regime',state.regime)); ai_reason=str(obj.get('reason',state.reason)); evidence=str(obj.get('evidence_quality','unknown')); inv=str(obj.get('invalidation',state.invalidation))
            if state.direction in ('UP','DOWN') and d==state.direction and c>=82 and e in ('A','B'):
                state.direction=d; state.confidence=min(97,max(state.confidence,c)); state.setup='READY'; state.entry_quality=e; state.reason=ai_reason+f" AI evidence: {evidence}."; state.last_ai='CLOUD + LOCAL'; state.regime=ai_reg; state.invalidation=inv; state.timeframe=str(obj.get('timeframe',timeframe)); state.expiry='2+ minutes' if state.timeframe in ('1m','5m') else '5+ minutes'
            else:
                state.direction='WAIT'; state.confidence=min(state.confidence,79); state.setup='WAITING'; state.reason='AI review did not independently confirm a clean entry. The safer decision is WAIT. '+ai_reason; state.last_ai='CLOUD + LOCAL'; state.entry_quality='C'
        except Exception:
            state.reason += ' Cloud AI review unavailable; local engine retained.'
        return state
