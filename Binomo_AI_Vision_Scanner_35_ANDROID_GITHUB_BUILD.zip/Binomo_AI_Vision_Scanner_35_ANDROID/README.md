# Binomo AI Vision Scanner PRO — Android Port

This project is an Android port of the 35-strategy AUTO COPY desktop system. It keeps the Flask/Python vision engine and the existing dashboard, while replacing Windows screen capture/Electron with two Android WebViews:

1. Upper WebView: Binomo browser view where the user logs in and selects the chart.
2. Lower WebView: the scanner dashboard.
3. Android captures the visible Binomo WebView and posts JPEG frames to the local Python vision engine.

## Build

The GitHub Actions workflow builds an arm64 debug APK using Gradle, Android Gradle Plugin 9.2, and Chaquopy 17 / Python 3.10. Chaquopy 17 supports Python 3.10–3.14 and Android Gradle Plugin 7.3–9.2, with minSdk 24.

The APK is for testing/sideloading. Real-account automatic trade execution is intentionally not implemented; real mode remains a manual-copy assistant. Paper/demo automation remains available.

## Important

The app needs Internet access for the embedded Binomo WebView. It does not require a PC once installed. The Python vision engine runs locally inside the Android app.
